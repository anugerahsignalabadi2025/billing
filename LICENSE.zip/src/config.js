module.exports = {
    //Nama owner
    ownerName: 'Miftah',

    // Nama bot
    botName: 'Anugrah Signal Abadi',

    footerTxt: 'Anugrah Signal Abadi',

    // Prefix command (contoh: ! . /)\
    prefix: '!',

    // Super Owner — hanya 1 nomor, akses penuh termasuk manage co-owner
    superOwner: [
              '6281297973316',
              '6285256029843',
              '6283136778501'
    ],
    // Co-Owner — bisa lebih dari satu, akses owner biasa
    coOwner: [
        '6283136778501',
        '6285256029843',
        '6283136778501'
    ],

    // Mode bot: 'public' → semua orang | 'self' → hanya owner
    botMode: 'public',

    // Otomatis centang biru pesan yang masuk
    autoRead: true,

    // Tampilkan indikator "mengetik..." saat membalas
    autoTyping: true,

    // Folder penyimpanan sesi login
    authFolder: './src/database/session',

    // Format: '120363xxxxxxxxx@newsletter'  — kosongkan jika tidak dipakai
    channelId: '',
    
};
